// Experimental prototype for Bedrock Dedicated Server you administer.
// @minecraft/server-net is pre-release and BDS-only; verify API versions and permissions for your build.
import { world, system } from "@minecraft/server";
import { http, HttpRequest, HttpRequestMethod, HttpHeader } from "@minecraft/server-net";

const VOICE_SERVER_URL = "https://YOUR-VOICE-SERVER.example/bridge/position";
const ROOM_NAME = "change-this-room";
const BRIDGE_TOKEN = "CHANGE-ME-TO-A-LONG-RANDOM-SECRET";

async function publishPosition(player) {
  try {
    const p = player.location;
    const req = new HttpRequest(VOICE_SERVER_URL);
    req.method = HttpRequestMethod.Post;
    req.headers = [
      new HttpHeader("Content-Type", "application/json"),
      new HttpHeader("Authorization", `Bearer ${BRIDGE_TOKEN}`)
    ];
    req.body = JSON.stringify({
      room: ROOM_NAME,
      name: player.name,
      x: p.x, y: p.y, z: p.z,
      dimension: player.dimension.id
    });
    await http.request(req);
  } catch (e) {
    console.warn(`[ProximityVoice] Position bridge failed: ${e}`);
  }
}
system.runInterval(() => {
  for (const player of world.getAllPlayers()) publishPosition(player);
}, 20); // approximately once per second
