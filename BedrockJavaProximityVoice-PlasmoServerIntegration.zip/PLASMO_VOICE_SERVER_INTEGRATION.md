# Plasmo Voice server-side integration (0.2.0)

This project now includes a Paper-side Plasmo Voice API add-on entry point.
It is intended for a Paper server that the operator controls and on which Plasmo Voice is installed.

## What is implemented

- Gradle compile-only dependency on the Plasmo Voice 2.1.17 server API.
- Optional loading of a Plasmo Voice add-on from the Paper plugin lifecycle.
- Registration of a dedicated `bedrock-bridge` Plasmo Voice source line.
- Existing authenticated position publishing to the companion Node service remains available.

## Important limitation

**This is not yet a complete Bedrock-to-Plasmo audio gateway.** Registering a source line does not convert WebRTC/Bedrock microphone audio into Plasmo Voice's encoded/encrypted 20 ms audio frames, authenticate an external Bedrock user as a voice participant, or return Plasmo Voice audio to Bedrock. Those are protocol/client-adapter tasks and require a separately implemented, tested audio transport. This module deliberately does not pretend to be a native Plasmo Voice client or bypass its protocol.

## Build

Requires JDK 21 and network access to the Paper and Plasmo Maven repositories:

```sh
cd java-plugin
./gradlew clean build
```

The output jar is under `java-plugin/build/libs/`.

## Install on a server you control

1. Install a compatible Paper server and Plasmo Voice plugin.
2. Copy `BedrockJavaProximityVoice-0.2.0.jar` into `plugins/`.
3. Start the server and check the log for `bedrock-bridge` source-line registration.
4. Configure the existing `voice-server-url` and matching `BRIDGE_TOKEN` for position publication.

This cannot be installed on DonutSMP by a player who does not have server-admin access. DonutSMP must approve and install server-side support for any integration with its voice service.
