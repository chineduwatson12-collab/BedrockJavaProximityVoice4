@echo off
setlocal
set "GRADLE_VERSION=8.10.2"
set "GRADLE_ZIP=gradle-%GRADLE_VERSION%-bin.zip"
set "GRADLE_HOME=%USERPROFILE%\.gradle\bootstrap\gradle-%GRADLE_VERSION%"
set "GRADLE_DIST=%GRADLE_HOME%\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_DIST%\bin\gradle.bat" (
  if not exist "%GRADLE_HOME%" mkdir "%GRADLE_HOME%"
  echo Gradle %GRADLE_VERSION% is not installed; downloading the official distribution...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/%GRADLE_ZIP%' -OutFile '%GRADLE_HOME%\%GRADLE_ZIP%'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%GRADLE_HOME%\%GRADLE_ZIP%' '%GRADLE_HOME%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_DIST%\bin\gradle.bat" -p "%~dp0" %*
exit /b %ERRORLEVEL%
