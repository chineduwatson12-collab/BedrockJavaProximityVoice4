package dev.openai.proximityvoice;

import su.plo.voice.api.server.PlasmoVoiceServer;

/** Isolated so the main plugin can still load when Plasmo Voice is not installed. */
public final class PlasmoVoiceAddonLoader {
    private PlasmoVoiceAddonLoader() {}

    public static void load() {
        PlasmoVoiceServer.getAddonsLoader().load(new PlasmoVoiceBridgeAddon());
    }
}
