package dev.openai.proximityvoice;

import su.plo.voice.api.addon.AddonInitializer;
import su.plo.voice.api.addon.InjectPlasmoVoice;
import su.plo.voice.api.addon.annotation.Addon;
import su.plo.voice.api.server.PlasmoVoiceServer;
import su.plo.voice.api.server.audio.line.ServerSourceLine;

/**
 * Server-side Plasmo Voice API integration point.
 *
 * This registers a dedicated source line for a future authenticated Bedrock audio adapter.
 * It intentionally does not forge Plasmo Voice client packets or accept unauthenticated audio.
 */
@Addon(
    id = "pv-addon-bedrock-bridge",
    name = "Bedrock Java Proximity Voice Bridge",
    version = "0.2.0",
    authors = {"BedrockJavaProximityVoice"}
)
public final class PlasmoVoiceBridgeAddon implements AddonInitializer {
    @InjectPlasmoVoice
    private PlasmoVoiceServer voiceServer;

    private ServerSourceLine bridgeLine;

    @Override
    public void onAddonInitialize() {
        bridgeLine = voiceServer.getSourceLineManager()
            .createBuilder(
                this,
                "bedrock-bridge",
                "pv.activation.bedrock_bridge",
                "plasmovoice:textures/icons/speaker_priority.png",
                5
            )
            .build();
        System.out.println("[BedrockJavaProximityVoice] Plasmo Voice API loaded; source line 'bedrock-bridge' registered.");
        System.out.println("[BedrockJavaProximityVoice] Audio packet translation is not enabled by this source-line registration alone.");
    }

    @Override
    public void onAddonShutdown() {
        // Plasmo Voice owns the source-line lifecycle and disposes it during addon shutdown.
        bridgeLine = null;
    }
}
