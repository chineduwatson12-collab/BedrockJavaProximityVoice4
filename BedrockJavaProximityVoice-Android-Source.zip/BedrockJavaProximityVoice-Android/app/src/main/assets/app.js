(() => {
  const $ = id => document.getElementById(id);
  let ws = null, localStream = null, room = "", muted = true, talking = false;
  const pcs = new Map(), names = new Map(), positions = new Map(), remoteAudio = new Map();
  const status = t => $("status").textContent = t;
  const baseUrl = () => ($("server").value.trim() || location.origin).replace(/\/+$/, "");
  const signalUrl = () => { const u = new URL(baseUrl()); u.protocol = u.protocol === "https:" ? "wss:" : "ws:"; u.pathname = "/signal"; u.search = ""; u.hash = ""; return u.toString(); };
  function send(obj) { if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
  function renderPlayers() {
    const ul = $("players"); ul.replaceChildren();
    const entries = [...names.entries()];
    if (!entries.length) { const li=document.createElement("li"); li.textContent="No other players connected"; ul.append(li); return; }
    for (const [id, name] of entries) {
      const li=document.createElement("li"), p=positions.get(name);
      li.textContent = name + (p ? ` — ${Math.round(p.x)}, ${Math.round(p.y)}, ${Math.round(p.z)}` : " — waiting for position");
      ul.append(li);
    }
  }
  function distance(a,b) { if (!a || !b || a.dimension !== b.dimension) return Infinity; return Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z); }
  function updateProximity() {
    const me = positions.get($("name").value.trim());
    const radius = Math.max(2, Math.min(256, Number($("radius").value) || 32));
    for (const [id, audio] of remoteAudio) {
      const them = positions.get(names.get(id));
      // If either side has no position data yet, allow room audio; true proximity starts when both positions arrive.
      const outOfRange = me && them ? distance(me, them) > radius : false;
      audio.muted = outOfRange;
    }
  }
  async function makePeer(id, name, offer) {
    if (pcs.has(id)) return pcs.get(id);
    names.set(id, name || "Player");
    const pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
    pcs.set(id, pc);
    localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
    pc.onicecandidate = e => { if (e.candidate) send({type:"ice",to:id,candidate:e.candidate}); };
    pc.ontrack = e => { let a=remoteAudio.get(id); if(!a){a=new Audio();a.autoplay=true;remoteAudio.set(id,a);} a.srcObject=e.streams[0]; updateProximity(); };
    pc.onconnectionstatechange = () => { if (pc.connectionState === "failed") status("Voice link failed; a TURN relay may be needed."); };
    if (offer) { const desc=await pc.createOffer(); await pc.setLocalDescription(desc); send({type:"offer",to:id,description:pc.localDescription}); }
    renderPlayers(); return pc;
  }
  async function handleMessage(m) {
    if (m.type === "error") return status(m.message);
    if (m.type === "joined") {
      for (const p of (m.peers||[])) await makePeer(p.id,p.name,false);
      $("mute").disabled=false; $("ptt").disabled=false; $("disconnect").disabled=false; $("connect").disabled=true;
      status(`Connected to room "${room}". Mic is muted until you hold the talk button.`);
    } else if (m.type === "peer-joined") {
      names.set(m.id,m.name); renderPlayers();
      // Only the existing participant initiates the offer.
      await makePeer(m.id,m.name,true);
    } else if (m.type === "peer-left") {
      pcs.get(m.id)?.close(); pcs.delete(m.id); remoteAudio.get(m.id)?.pause(); remoteAudio.delete(m.id); names.delete(m.id); renderPlayers();
    } else if (m.type === "offer") {
      const pc = await makePeer(m.from,m.fromName,false);
      await pc.setRemoteDescription(m.description);
      const answer=await pc.createAnswer(); await pc.setLocalDescription(answer);
      send({type:"answer",to:m.from,description:pc.localDescription});
    } else if (m.type === "answer") {
      await pcs.get(m.from)?.setRemoteDescription(m.description);
    } else if (m.type === "ice") {
      try { await pcs.get(m.from)?.addIceCandidate(m.candidate); } catch {}
    } else if (m.type === "position") {
      positions.set(m.name,{x:m.x,y:m.y,z:m.z,dimension:m.dimension||"overworld"});
      renderPlayers(); updateProximity();
    } else if (m.type === "positions") {
      for (const [n,p] of Object.entries(m.players||{})) positions.set(n,p);
      renderPlayers(); updateProximity();
    }
  }
  $("connect").onclick = async () => {
    room=$("room").value.trim();
    if(!room) return status("Enter a room name.");
    if(!navigator.mediaDevices?.getUserMedia) return status("Microphone access needs HTTPS or localhost in a supported browser.");
    try {
      localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
      localStream.getAudioTracks().forEach(t=>t.enabled=false);
      muted=true; talking=false; $("mute").textContent="Mic muted"; $("ptt").textContent="HOLD TO TALK";
      ws=new WebSocket(signalUrl());
      ws.onopen=()=>send({type:"join",room,name:$("name").value.trim()||"Player"});
      ws.onmessage=async e=>{try{await handleMessage(JSON.parse(e.data));}catch(err){console.error(err);status("Voice setup error: "+err.message);}};
      ws.onerror=()=>status("Could not connect. Check server URL and HTTPS/TLS.");
      ws.onclose=()=>{if($("connect").disabled)status("Disconnected from voice server.");};
    } catch(e) { status("Microphone permission/setup failed: "+e.message); }
  };
  function setTalking(on) {
    talking = Boolean(on) && !muted && Boolean(localStream);
    localStream?.getAudioTracks().forEach(t => t.enabled = talking);
    $("ptt").classList.toggle("talking", talking);
    $("ptt").textContent = talking ? "SPEAKING — RELEASE TO MUTE" : "HOLD TO TALK";
  }
  const ptt = $("ptt");
  ptt.addEventListener("pointerdown", e => { if (!ptt.disabled) { e.preventDefault(); ptt.setPointerCapture?.(e.pointerId); setTalking(true); } });
  ["pointerup","pointercancel","lostpointercapture","pointerleave"].forEach(ev => ptt.addEventListener(ev, () => setTalking(false)));
  ptt.addEventListener("contextmenu", e => e.preventDefault());
  $("mute").onclick=()=>{muted=!muted;if(muted)setTalking(false);$("mute").textContent=muted?"Mic muted":"Mic unmuted — hold to talk";updateProximity();};
  $("disconnect").onclick=()=>{
    send({type:"leave"});ws?.close();pcs.forEach(pc=>pc.close());pcs.clear();
    remoteAudio.forEach(a=>a.pause());remoteAudio.clear();localStream?.getTracks().forEach(t=>t.stop());localStream=null;
    names.clear();positions.clear();muted=true;talking=false;$("connect").disabled=false;$("mute").disabled=true;$("ptt").disabled=true;$("ptt").classList.remove("talking");$("ptt").textContent="HOLD TO TALK";$("disconnect").disabled=true;$("mute").textContent="Mic muted";
    renderPlayers();status("Disconnected.");
  };
  $("radius").addEventListener("input",updateProximity);
})();
